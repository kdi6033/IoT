import { Component } from '@angular/core';
//import { WifiWizard2Original } from '@awesome-cordova-plugins/wifi-wizard-2';
//import { WifiWizard2 } from '@awesome-cordova-plugins/wifi-wizard-2';
import { WifiScanResultsOptions, WifiWizard2 } from '@awesome-cordova-plugins/wifi-wizard-2/ngx';
import {FormControl, FormGroup, Validators} from '@angular/forms';
//import { WifiWizard2Original } from '@awesome-cordova-plugins/wifi-wizard-2';
//declare var WifiWizard2 : any;

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})

export class Tab2Page {
  //constructor() {}
  constructor() { }
  public results = [];
  info_txt = "";
  perm = "";
  public IsCalling = false;
  public str = "";
  public propertyNames;
  public propertyValues;
  public out_array = [];
  private wifiWizard2 = new WifiWizard2();
  //private wifiWizard2: WifiWizard2Original;
  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  private getForm() {
    
  }
  private success () {
    
  }
  private fail () {
    return false;
  }
  private submit_form(path, params, method) {
    method = method || "post";
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
    form._submit_function_ = form.submit;
    for (var key in params) {
      if (params.hasOwnProperty(key)) {
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", key);
        hiddenField.setAttribute("value", params[key]);
        form.appendChild(hiddenField);
      }
    }
    document.body.appendChild(form);
    form._submit_function_();
  }

  async getNetworks() {
    this.info_txt = "loading..";
    try {
      this.IsCalling = true; //button disabled
      //this.wifiWizard2.requestPermission();
      this.wifiWizard2.startScan();
      let results = await this.wifiWizard2.scan();
      this.str = JSON.stringify(results);
      console.log("Type of res :");
      console.log(typeof(this.results));
      console.log(this.str);
      this.str = JSON.parse(this.str);
      console.log(typeof(this.str));
      this.propertyNames = Object.keys(this.str);
      this.propertyValues = Object.values(this.str);
      console.log(this.propertyNames);
      console.log(this.propertyValues);
      for (let element in this.propertyNames){
        this.out_array[element] = JSON.stringify(this.propertyValues[element]);
      }

      /*for (let element in this.out_array){
        console.log(this.out_array[element]);
        if (this.out_array[element].includes("lightTalk")) {
          var found_obj = JSON.parse(this.out_array[element]);
          console.log(found_obj.SSID);
          WifiWizard2.connect(found_obj.SSID, true);
          console.log("Connected to lightTalk");
          //this.submit_form('http://192.168.4.1', 'POST', {'n' : this.wifi_name, 'p' : this.wifi_pw});
          //load 192.168.4.1 in the background
          //and fill the forms without loading the website.
          //then return to current tab.
        }
      }*/
      this.info_txt = "";
    } catch (error) {
      this.info_txt = error;
    }
      await this.delay(10000); //delay 10 secs
      this.IsCalling = false; //enable button
  }
}
